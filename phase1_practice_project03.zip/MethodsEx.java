public class MethodsEx{
	void display()
	{
		System.out.println("my name is dispaly");
		
	}
	public static void start()
	{
		System.out.println("This is static method");
	}
	void show(int a, int b)
	{
		int c=a+b;
		System.out.println(c);
		
	}

	public static void main(String[] args) {
		 MethodsEx m = new MethodsEx();
		 m.display();
		 m.show(5,6);
		 MethodsEx.start();
		 start();
		}
	
	}